# Our Digit Platform V4 — GitHub Actions APK build

## What this does
The included GitHub Actions workflow builds the Android app automatically and publishes the debug APK as a downloadable workflow artifact.

## Important
The repository needs a Gradle wrapper (`gradlew`, `gradlew.bat`, and `gradle/wrapper/*`).
If the wrapper is missing, open this project once in Android Studio and choose:
**File → Sync Project with Gradle Files**, then generate/sync the Gradle wrapper, or run:
`gradle wrapper`

## GitHub steps
1. Create a new GitHub repository.
2. Upload all files in this project.
3. Commit to `main` (or `master`).
4. Open **Actions**.
5. Select **Build Android APK**.
6. Click **Run workflow**.
7. When it finishes, open the workflow run and download:
   `our-digit-platform-v4-debug-apk`

This APK is demo-only and uses virtual money.
